#include <jni.h>
#include <string>
#include <android/log.h>

extern "C" {

//#include <opencv2/core/core.hpp>
//#include <opencv2/imgcodecs.hpp>

#include <opencv2/opencv.hpp>
#include <android/bitmap.h>

using namespace cv;

//JNIEXPORT void JNICALL Java_lr_wcwl_com_lr_opencv_android_demo_CppMosaicUtils_opencvImage(
//        JNIEnv *env,
//        jobject jobj,
//        jintArray jsrcArray,
//        jintArray jdstArray,
//        jint jsrcWidth,
//        jint jsrcHeight,
//        jint jdstWidth,
//        jint jdstHeight);

JNIEXPORT void JNICALL Java_lr_wcwl_com_lr_opencv_android_demo_CppMosaicUtils_opencvImage(
        JNIEnv *env,
        jobject jobj,
        jobject jsrcBitmap,
        jobject jdstBitmap);

}

#  define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, "error", __VA_ARGS__))
#  define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, "debug", __VA_ARGS__))

/*
 * Class:     org_opencv_android_Utils
 * Method:    void nBitmapToMat2(Bitmap b, long m_addr, boolean unPremultiplyAlpha)
 */
void BitmapToMat2(JNIEnv * env, jobject& bitmap, Mat &mat, jboolean needUnPremultiplyAlpha)
{
    AndroidBitmapInfo  info;
    void *pixels = 0;
    Mat &dst = mat;

    try {
        LOGD("nBitmapToMat");
        CV_Assert( AndroidBitmap_getInfo(env, bitmap, &info) >= 0 );
        CV_Assert( info.format == ANDROID_BITMAP_FORMAT_RGBA_8888 ||
                   info.format == ANDROID_BITMAP_FORMAT_RGB_565 );
        CV_Assert( AndroidBitmap_lockPixels(env, bitmap, &pixels) >= 0 );
        CV_Assert( pixels );
        dst.create(info.height, info.width, CV_8UC4);
        if( info.format == ANDROID_BITMAP_FORMAT_RGBA_8888 )
        {
            LOGD("nBitmapToMat: RGBA_8888 -> CV_8UC4");
            Mat tmp(info.height, info.width, CV_8UC4, pixels);
            if(needUnPremultiplyAlpha) cvtColor(tmp, dst, COLOR_mRGBA2RGBA);
            else tmp.copyTo(dst);
        } else {
            // info.format == ANDROID_BITMAP_FORMAT_RGB_565
            LOGD("nBitmapToMat: RGB_565 -> CV_8UC4");
            Mat tmp(info.height, info.width, CV_8UC2, pixels);
            cvtColor(tmp, dst, COLOR_BGR5652RGBA);
        }
        AndroidBitmap_unlockPixels(env, bitmap);
        return;
    } catch(const cv::Exception& e) {
        AndroidBitmap_unlockPixels(env, bitmap);
        LOGE("nBitmapToMat catched cv::Exception: %s", e.what());
        jclass je = env->FindClass("org/opencv/core/CvException");
        if(!je) je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, e.what());
        return;
    } catch (...) {
        AndroidBitmap_unlockPixels(env, bitmap);
        LOGE("nBitmapToMat catched unknown exception (...)");
        jclass je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, "Unknown exception in JNI code {nBitmapToMat}");
        return;
    }
}

// old signature is left for binary compatibility with 2.4.0 & 2.4.1, to removed in 2.5


void BitmapToMat(JNIEnv * env, jobject &bitmap, Mat &mat)
{
    BitmapToMat2(env, bitmap, mat, false);
}

/*
 * Class:     org_opencv_android_Utils
 * Method:    void nMatToBitmap2(long m_addr, Bitmap b, boolean premultiplyAlpha)
 */

void MatToBitmap2(JNIEnv * env, Mat &mat, jobject bitmap, jboolean needPremultiplyAlpha)
{
    AndroidBitmapInfo  info;
    void *pixels = 0;
    Mat &src = mat;

    try {
        LOGD("nMatToBitmap");
        CV_Assert( AndroidBitmap_getInfo(env, bitmap, &info) >= 0 );
        CV_Assert( info.format == ANDROID_BITMAP_FORMAT_RGBA_8888 ||
                   info.format == ANDROID_BITMAP_FORMAT_RGB_565 );
        CV_Assert( src.dims == 2 && info.height == (uint32_t)src.rows && info.width == (uint32_t)src.cols );
        CV_Assert( src.type() == CV_8UC1 || src.type() == CV_8UC3 || src.type() == CV_8UC4 );
        CV_Assert( AndroidBitmap_lockPixels(env, bitmap, &pixels) >= 0 );
        CV_Assert( pixels );
        if( info.format == ANDROID_BITMAP_FORMAT_RGBA_8888 )
        {
            Mat tmp(info.height, info.width, CV_8UC4, pixels);
            if(src.type() == CV_8UC1)
            {
                LOGD("nMatToBitmap: CV_8UC1 -> RGBA_8888");
                cvtColor(src, tmp, COLOR_GRAY2RGBA);
            } else if(src.type() == CV_8UC3){
                LOGD("nMatToBitmap: CV_8UC3 -> RGBA_8888");
                cvtColor(src, tmp, COLOR_RGB2RGBA);
            } else if(src.type() == CV_8UC4){
                LOGD("nMatToBitmap: CV_8UC4 -> RGBA_8888");
                if(needPremultiplyAlpha) cvtColor(src, tmp, COLOR_RGBA2mRGBA);
                else src.copyTo(tmp);
            }
        } else {
            // info.format == ANDROID_BITMAP_FORMAT_RGB_565
            Mat tmp(info.height, info.width, CV_8UC2, pixels);
            if(src.type() == CV_8UC1)
            {
                LOGD("nMatToBitmap: CV_8UC1 -> RGB_565");
                cvtColor(src, tmp, COLOR_GRAY2BGR565);
            } else if(src.type() == CV_8UC3){
                LOGD("nMatToBitmap: CV_8UC3 -> RGB_565");
                cvtColor(src, tmp, COLOR_RGB2BGR565);
            } else if(src.type() == CV_8UC4){
                LOGD("nMatToBitmap: CV_8UC4 -> RGB_565");
                cvtColor(src, tmp, COLOR_RGBA2BGR565);
            }
        }
        AndroidBitmap_unlockPixels(env, bitmap);
        return;
    } catch(const cv::Exception& e) {
        AndroidBitmap_unlockPixels(env, bitmap);
        LOGE("nMatToBitmap catched cv::Exception: %s", e.what());
        jclass je = env->FindClass("org/opencv/core/CvException");
        if(!je) je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, e.what());
        return;
    } catch (...) {
        AndroidBitmap_unlockPixels(env, bitmap);
        LOGE("nMatToBitmap catched unknown exception (...)");
        jclass je = env->FindClass("java/lang/Exception");
        env->ThrowNew(je, "Unknown exception in JNI code {nMatToBitmap}");
        return;
    }
}

// old signature is left for binary compatibility with 2.4.0 & 2.4.1, to removed in 2.5
void MatToBitmap(JNIEnv * env, Mat &mat, jobject bitmap)
{
    MatToBitmap2(env, mat, bitmap, false);
}



//JNIEXPORT void JNICALL Java_lr_wcwl_com_lr_opencv_android_demo_CppMosaicUtils_opencvImage(
//        JNIEnv *env,
//        jobject jobj,
//        jintArray jsrcArray,
//        jintArray jdstArray,
//        jint jsrcWidth,
//        jint jsrcHeight,
//        jint jdstWidth,
//        jint jdstHeight) {
//
//    //第一步：准备两张图片
//    //imread 函数：读取文件, 返回一个 Mat 矩阵（是 OpenCV框架最基本数据类型）
//
//    jint *csrcArray = env->GetIntArrayElements(jsrcArray, JNI_FALSE);
//    jint *cdstArray = env->GetIntArrayElements(jdstArray, JNI_FALSE);
//
//    Mat mat_image_src(jsrcWidth, jsrcHeight, CV_8UC4, csrcArray);
//    Mat mat_image_dst(jdstWidth, jdstHeight, CV_8UC4, jdstArray);
//
//    //第二步：创建叠加区域，开辟了一块内存空间
//    Mat mat_roi = mat_image_src(Rect2i(0, 0, mat_image_dst.cols, mat_image_dst.rows));
//
//    //第三步：图片叠加，加水印->合并之后覆盖原来的图片
//    //参数一：第一个图片数组
//    //参数二：第一个图片数组的权重为0
//    //参数三：第二个图片数组
//    //参数四：第二个图片数组的权重为1
//    //参数五：权重和基础之上的标量值
//    //参数六：输出的图片数组
//    //dst = src1*alpha + src2*beta + gamma;
//    //伪代码：mat_roi * 0 + mat_image_dst * 1 + 0
//    addWeighted(mat_roi, 0, mat_image_dst, 1, 0, mat_roi);
//
//    //第四步：转成 Java 数组 -> 更新
//    env->ReleaseIntArrayElements(jsrcArray, csrcArray, 0);
//
//}

JNIEXPORT void JNICALL Java_lr_wcwl_com_lr_opencv_android_demo_CppMosaicUtils_opencvImage(
        JNIEnv *env,
        jobject jobj,
        jobject jsrcBitmap,
        jobject jdstBitmap) {

    //第一步：准备两张图片
    // 将 Android Bitmap 转成 openCV Mat
    Mat mat_image_src;
    BitmapToMat(env, jsrcBitmap, mat_image_src);
    Mat mat_image_dst;
    BitmapToMat(env, jdstBitmap, mat_image_dst);

    //第二步：创建叠加区域，开辟了一块内存空间
    Mat mat_roi = mat_image_src(Rect2i(0, 0, mat_image_dst.cols, mat_image_dst.rows));

    //第三步：图片叠加，加水印->合并之后覆盖原来的图片
    //参数一：第一个图片数组
    //参数二：第一个图片数组的权重为0
    //参数三：第二个图片数组
    //参数四：第二个图片数组的权重为1
    //参数五：权重和基础之上的标量值
    //参数六：输出的图片数组
    //dst = src1*alpha + src2*beta + gamma;
    //伪代码：mat_roi * 0 + mat_image_dst * 1 + 0
    addWeighted(mat_roi, 0, mat_image_dst, 1, 0, mat_roi);

    //第四步：将  openCV Mat 转成 Android Bitmap
    MatToBitmap(env, mat_image_src, jsrcBitmap);

}
