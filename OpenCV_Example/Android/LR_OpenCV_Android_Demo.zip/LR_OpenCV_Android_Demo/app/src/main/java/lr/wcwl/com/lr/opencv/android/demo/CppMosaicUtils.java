package lr.wcwl.com.lr.opencv.android.demo;

import android.graphics.Bitmap;


/**
 * 作者: Dream on 2017/8/2 21:41
 * QQ:510278658
 * E-mail:510278658@qq.com
 */
public class CppMosaicUtils {

    static {
        System.loadLibrary("native-lib");
    }
//原始代码 -> 存在兼容性问题
//    //Java层调用
//    public static Bitmap image(Bitmap srcBitmap, Bitmap dstBitmap){
//        //第一步：确定图片大小
//        int srcWidth = srcBitmap.getWidth();
//        int srcHeight = srcBitmap.getHeight();
//
//        int dstWidth = dstBitmap.getWidth();
//        int dstHeight = dstBitmap.getHeight();
//
//        //第二步：将图片(bitmap)->像素数组
//        int[] srcArray = new int[srcWidth * srcHeight];
//        srcBitmap.getPixels(srcArray, 0, srcWidth, 0, 0, srcWidth, srcHeight);
//
//        int[] dstArray = new int[dstWidth * dstHeight];
//        dstBitmap.getPixels(dstArray, 0, dstWidth, 0, 0, dstWidth, dstHeight);
//
//        //第三步：调用NDK底层实现
//        opencvImage(srcArray, dstArray, srcWidth, srcHeight, dstWidth, dstHeight);
//
//        //第四步：创建一张图片
//        return Bitmap.createBitmap(srcArray, srcWidth, srcHeight, Bitmap.Config.ARGB_8888);
//    }
//
//
//    //NDK层代码
//    //第三步：定义本地native方法->Java上层native方法->底层有对应
//    public native static void opencvImage(int[] src, int[] dst, int srcWidth, int srcHeight, int dstWidth, int dstHeight);

    // 解决了兼容性问题
    public native static void opencvImage(Bitmap srcBitmap, Bitmap dstBitmap);
}
