package lr.wcwl.com.lr.opencv.android.demo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.imageView);
    }

    public void clickNormal(View v){
        imageView.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.mipmap.image1));
    }

    public void clickMix(View v){
//        Bitmap srcBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.image1);
//        Bitmap dstBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.image2);
//        Bitmap resultBitmap = CppMosaicUtils.image(srcBitmap, dstBitmap);
//        imageView.setImageBitmap(resultBitmap);

        Bitmap srcBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.image1);
        Bitmap dstBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.image2);
        CppMosaicUtils.opencvImage(srcBitmap, dstBitmap);
        imageView.setImageBitmap(srcBitmap);
    }


}
