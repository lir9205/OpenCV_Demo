package lr.wcwl.com.opencv.imgproc.android;

import android.graphics.Bitmap;


/**
 * 作者: Dream on 2017/8/2 21:41
 * QQ:510278658
 * E-mail:510278658@qq.com
 */
public class CppImageUtils {

    static {
        System.loadLibrary("native-lib");
    }
    // 内容一：OpenCV 开发 -> 图像组件 -> imgProc 组件
    // 第一点：形态学滤波 -> morphologyEx()函数
    public native static void opencvMorphologyEx(Bitmap srcBitmap);

}
