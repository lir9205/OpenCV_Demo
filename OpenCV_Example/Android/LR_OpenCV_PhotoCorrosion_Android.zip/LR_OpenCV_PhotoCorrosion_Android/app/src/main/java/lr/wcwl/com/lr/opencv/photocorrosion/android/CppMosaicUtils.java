package lr.wcwl.com.lr.opencv.photocorrosion.android;

import android.graphics.Bitmap;


/**
 * 作者: Dream on 2017/8/2 21:41
 * QQ:510278658
 * E-mail:510278658@qq.com
 */
public class CppMosaicUtils {

    static {
        System.loadLibrary("native-lib");
    }
    // 案例一：图片腐蚀
    public native static void opencvImageErode(Bitmap srcBitmap);
    // 案例二：图片模糊
    public native static void opencvImageBlur(Bitmap srcBitmap);
    // 案例三：图片边缘检测 -> 图片轮廓
    public native static void opencvImageCanney(Bitmap srcBitmap);

}
